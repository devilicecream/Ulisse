package com.example.ulisse2;

import android.support.v4.app.FragmentManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;


import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: dave
 * Date: 23/05/13
 * Time: 14.45
 * To change this template use File | Settings | File Templates.
 */
public class PagerAdapter extends FragmentPagerAdapter {

    // fragments to instantiate in the viewpager
    private List<Fragment> fragments;

    // constructor
    public PagerAdapter(FragmentManager fm, List<android.support.v4.app.Fragment> fragments) {
        super(fm);
        this.fragments = fragments;
    }

    // return access to fragment from position, required override
    @Override
    public android.support.v4.app.Fragment getItem(int position) {
        return this.fragments.get(position);
    }

    // number of fragments in list, required override
    @Override
    public int getCount() {
        return this.fragments.size();
    }

}

